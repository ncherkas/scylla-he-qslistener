=====================================
Scylla Monitoring Stack Alert Manager
=====================================

.. toctree::
   :maxdepth: 2
   :hidden:

   Alerting <alerting>


Alerts are a Prometheus enhancement used to notify you that something is wrong in your system.
Choose a topic to begin:

* :doc:`Alerting <alerting>`
