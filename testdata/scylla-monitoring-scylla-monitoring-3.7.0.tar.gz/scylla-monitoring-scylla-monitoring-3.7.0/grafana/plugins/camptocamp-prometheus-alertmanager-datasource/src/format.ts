export enum Format {
  Table = 'table',
  Timeseries = 'timeseries',
}
