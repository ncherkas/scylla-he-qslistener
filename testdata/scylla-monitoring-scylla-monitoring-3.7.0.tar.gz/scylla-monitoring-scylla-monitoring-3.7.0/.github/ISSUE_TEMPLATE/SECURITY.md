The Scylla-Monitoring team and community take security bugs very seriously.
We appreciate your efforts to disclose your findings responsibly and will acknowledge your contributions.
To report a security issue, email security@scylladb.com. The Scylla-Monitoring team will
send a response indicating the next steps in handling your report. 
Thanks for helping make Scylla-Monitoring safe for everyone!