#!/usr/bin/env bash

./start-all.sh -e $@
