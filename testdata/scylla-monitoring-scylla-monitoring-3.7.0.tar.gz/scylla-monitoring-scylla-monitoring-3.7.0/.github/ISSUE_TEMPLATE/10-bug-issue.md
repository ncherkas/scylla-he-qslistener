---
name: "🐛 Report a Scylla-Monitoring bug"
about: Use this template for reporting a suspected bug or an issue
title: ''
labels: bug
assignees: ''
---

*Installation details*
Panel Name:
Dashboard Name:
Scylla-Monitoring Version: (can be found at the buttom of the overview dashboard)
Scylla-Version:

