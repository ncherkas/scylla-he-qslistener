---
name: "📖 Documentation issue: I found an issue with the documentation"
about: Use this template for reporting a feature or a problem in the documentation
labels: documentation
assignees: 'lauranovich'
---

Please make sure that this is a documentation related 

**System information**
- link to the documentation page and section
- Are you willing to contribute it (Yes/No):

**Describe the situation now**

**What needs to be there**

**Any Other info.**