#!/usr/bin/env bash

echo "This file is deprecated and kept for backward compatibility. You should use start-all.sh directly"

source start-all.sh
