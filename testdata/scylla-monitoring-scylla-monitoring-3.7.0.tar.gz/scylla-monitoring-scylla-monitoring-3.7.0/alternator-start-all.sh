#!/usr/bin/env bash

./start-all.sh -S alternator $@
